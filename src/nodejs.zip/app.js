const express = require('express');
const webshot = require('webshot');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();
const axios = require('axios');
//const server = require('http').createServer(app);       // for socket webserver
//const io = require('socket.io')(server);                // for socket webserver
var os = require( 'os' );
//const cors = require('cors');
const port = 3000;
                                                                // get PCs network interfaces (json object)
var jsonObj = JSON.stringify(os.networkInterfaces());           // prepare returned jsonobject for parsing to object
jsonObj = JSON.parse(jsonObj);                                  // parsing into object

const serverIP = jsonObj['Wi-Fi'][1]['address'];
console.log("IP_ADRESS: "+serverIP);           

var boolNextPart = false;
var counter = 0;
/*
io.on('connection', () => { 
    console.log('Client connected');
});
server.listen(80);          // socket webserver
*/

//app.use(cors());
app.use(function(req, res, next) {
	res.header("Access-Control-Allow-Origin", "*");
	res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
	next();
});
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json());
app.use(express.static('public'));

app.get('/', function(req, res) {
    res.sendFile(__dirname + '/index.html');
});

app.post('/espIP', function (req, res, next) {
    let url = req.body.data;
    //url = "10.0.0.144";
    console.log(`Sending request to esp ${url}`);

    axios.post(`http://${url}/espIP`,
        {
            data: `${serverIP}`
        })
        .then((res) => {
            console.log(res.data);
        })
        .catch((error) => {
            console.error(error)
        });
    res.send("ok");
});

app.get('/sendNextPartOfImg', function(req, res, next){
   console.log("Request received to sending next part  [OK] " +counter);
   counter ++;
   boolNextPart = true;
   //io.sockets.emit('sendNextPart',null);      // uncomment if using socket
   res.send("request received [nodeJS]"); 
});

app.get('/avaiableNext', function (req, res) {
    if(boolNextPart){
        boolNextPart = false;
        res.send("1");
    }
    else{
        res.send("0");
    }
});

app.post('/takescreenshot', (req, res, next) => {
    console.log('Taking screenshot ...');
 
    let url = req.body.data;
    console.log(url);
    
    var options = {   
        windowSize: {
          width: 1920
        , height: 1080
        }
      , 
      shotSize: {
          width: 1920
        , height: 1080
        }
    };
        
    let imgdir =  __dirname+"/public/screenshot/picture.png";

    webshot("http://"+url,imgdir, function(err){
        if(err){
            console.log(`${err}     [ERROR]`);
        }
        else{
            let img = fs.readFileSync(imgdir);
            console.log('Screenshot returned    [OK]');        
            res.writeHead(200, {'Content-Type': 'image/png' });
            res.end(img, 'binary');
        }
    });
});

app.listen(port, () => console.log(`SERVER LISTENING PORT ${port} ...`));        // http webserver