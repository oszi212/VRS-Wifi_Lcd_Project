$(document).ready(function() { 
          
    // Global variables

    var inputURL = "";                      // address of requested page
    var espIP;                           // esp webserver's IP address, which one must be determined by user
    var xmlhttpPOST = new XMLHttpRequest();     // HttpRequest instance
    var xmlhttpGET = new XMLHttpRequest();
    var imgSrc ="";         
    var mainbody = $("#mainbody");          // mainbody's content represents the captureable area, where the captured screenshot of input url's will be pasted 
    var getCanvas;  
    var cap_canv = document.getElementById("capturedCanvas");
    var mouseX = 0;             // storing mouse positions
    var mouseY = 0;
    var clipX = 0;              // clipping coordinates of clipped (cutted) img, which size(dimension) can be 128 or 256 px
    var clipY = 0;
    var objIt1;                    // interval Object for automated displaying (refreshing)
    var objIt2;                    // interval object for checking sending next part
    var interval;               // checking changes rate in minutes
    var scale = 1;                  // scale during img cutting, it depends on dimension's size
    var lindex;                 // lower index of clippedImgBuffer array, which part of it will displayed
    var clippedImgBuffer="";          // storing clipped images pixels
    var prev_clippedImgBuffer="";     // same as above, but it is needed for automated displaying 
    var squareHidden = false;
    var displaying = false;
    var range = 500;                 // how many pixels send during one httprequest
   
    // if using socket feedback
    /****** SOCKET START CODE  ******/ 
    
    //var serverIP = location.host.replace(/\:.*/i,'');
    //var socket = io(serverIP+':80'); //load socket.io-client and connect to the host that serves the page
	/*	
    socket.on('connect', function(){
        console.log('Client connected');
    });
    socket.on('sendNextPart', function(data){
        if(displaying){              
            let uindex = lindex + range;     
            uindex = uindex > clippedImgBuffer.length ? clippedImgBuffer.length: uindex;

            let data = clippedImgBuffer.slice(lindex, uindex);
            console.log("Selected range from buffer: ");
            console.log(`lowerindex ${lindex}`);
            console.log(`upperindex ${uindex}`);

            lindex = uindex;
            HttpResponseToVoid()
        
            if(lindex == clippedImgBuffer.length){         // if all pixels displayed, set displaying to false
                displaying = false;
                setStatusSpan("DONE", "blue");
                showSnackbar("Image displayed on LCD!");
            }
            else{
                sendPOSTrequest("http://"+espIP+":80/displayImgPart", data, "application/json;charset=UTF-8", "text", 0);       // send pixels to webserver for displaying
            }
        }
    });
    socket.on('disconnect', function(){
        console.log('Client disconnected');
    });
    */
    /***** SOCKET END CODE ******/
    
    /***** Functions which set responseType of global Http objects *****/
    function HttpResponseToVoid(xmlhttp){
        xmlhttp.onreadystatechange = function(){};
    }

    function HttpResponseToImgSrc(xmlhttp){
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == XMLHttpRequest.DONE && this.status == 200) {
                let src = URL.createObjectURL(xmlhttp.response);//xmlhttp.response;//'data:image/png;base64,' + btoa(xmlhttp.response);
                imgSrc = src;
                document.getElementById("pic1").src = src;
                showSnackbar(`Screenshot captured about ${inputURL} site!`);
            }
        }
    }

    function HttpResponseForAutomation(xmlhttp) {
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == XMLHttpRequest.DONE && this.status == 200) {
                let src = URL.createObjectURL(xmlhttp.response);//xmlhttp.response;//'data:image/png;base64,' + btoa(xmlhttp.response);
                imgSrc = src;
                document.getElementById("pic1").src = src;
                showSnackbar(`Screenshot captured about ${inputURL} site!`);
             //   setIntervalObject2(true);
                takePartOfImg(true);
                
                HttpResponseForCheckNext(xmlhttpGET);
                setIntervalObject2(true);
              //  
                
                //setIntervalObject2(true);       //start
            }
        }
    }

    function HttpResponseForCheckNext(xmlhttp) {
        xmlhttp.onreadystatechange = function() {
            checkNextPartviaHttp();
        }
    }

    function setIntervalObject1(status){        //interval object for POST request
        if(status){         //status true, starts interval object
            clearInterval(objIt1);
            objIt1 = setInterval(() => {
                HttpResponseForAutomation(xmlhttpPOST);
                sendPOSTrequest("/takescreenshot", inputURL, "application/json;charset=UTF-8", "blob",0);
            }, interval);
        }
        else{              // false stops it
            clearInterval(objIt1);
        }
    }

    function setIntervalObject2(status){        //interval object for GET request
        if(status){         //status true, starts interval object
            clearInterval(objIt2);
            objIt2 = setInterval(() => {
                sendGETrequest("/avaiableNext","application/json;charset=UTF-8", "application/json",0);
            }, 5* 1000);
        }
        else{              // false stops it
            clearInterval(objIt2);
        }
    }

    /****** THIS FUNCTION SEND IN SPECIFIED INTERVAL HTTTP REQUEST TO NODEJS, CHECKS THE SENDING NEXT PART OF SELECTED AREA ******/
    function checkNextPartviaHttp(){
        if (xmlhttpGET.readyState == XMLHttpRequest.DONE && xmlhttpGET.status == 200) {
            let res = xmlhttpGET.response;//xmlhttp.response;//'data:image/png;base64,' + btoa(xmlhttp.response);
            
            if(displaying){
                if(res == "1"){
                    let uindex = lindex + range;     
                    uindex = uindex > clippedImgBuffer.length ? clippedImgBuffer.length: uindex;

                    let data = clippedImgBuffer.slice(lindex, uindex);
                    console.log("Selected range from buffer: ");
                    console.log(`lowerindex ${lindex}`);
                    console.log(`upperindex ${uindex}`);
        
                    lindex = uindex;
                    HttpResponseToVoid(xmlhttpPOST)
                
                    if(lindex == clippedImgBuffer.length){         // if all pixels displayed, set displaying to false
                        displaying = false;
                        setStatusSpan("DONE", "blue");
                        showSnackbar("Image displayed on LCD!");
                    }
                    else{
                        sendPOSTrequest("http://"+espIP+":80/displayImgPart", data, "application/json;charset=UTF-8", "text", 0);       // send pixels to webserver for displaying
                    }
                }
            }
            else{
                setIntervalObject2(false);      // stop
               // clearInterval(objIt2);  // check todo
            }
        }
    }
    
    /****** FUNCTION BELOV CUT OF SELECTED AREA FROM IMAGE ******/
    function takePartOfImg(automation){
       
                                // box, where will be stored cutted img (this one is displayed on lcd) 
        let boxWidth = $("#divToShow").width();  
        let boxHeight =  $("#divToShow").height(); 
                                // defining helper canvas where will be cutted box from main canvas
        cap_canv.width = boxWidth;
        cap_canv.height = boxHeight;
        let cap_ctx = cap_canv.getContext('2d');
        cap_ctx.clearRect(0, 0, cap_canv.width, cap_canv.height);       // clearing the captured box
       
        delay(1000);
        html2canvas(mainbody, { allowTaint: true, useCORS: true,
            onrendered: function(canvas) { 
                getCanvas = canvas; 
                cap_ctx.drawImage(
                    getCanvas, 
                    clipX+1,           //Start Clipping
                    clipY+1,           //Start Clipping
                    boxWidth,           //Clipping Width
                    boxHeight,          //Clipping Height
                    0,                  //Place X
                    0,                  //Place Y
                    cap_canv.width,     //Place Width
                    cap_canv.height     //Place Height
                );
                console.log("Part of img clipped");
                
                let imgData = cap_ctx.getImageData(0, 0, cap_canv.width, cap_canv.height);
                clippedImgBuffer = createImgBuffer(imgData);
              
                console.log(`Clipped image size: ${clippedImgBuffer.length}`);
        
                let data = clippedImgBuffer.slice(0, range);    // 1365 
                lindex = range;                                  // 1365
                HttpResponseToVoid(xmlhttpPOST);

                if(!automation){        // if isn't set automation, we don't need compare clipped areas
                    displaying = true;
                    setStatusSpan("ACTIVE", "green"); 
                    sendPOSTrequest("http://"+espIP+":80/displayImg", data, "application/json;charset=UTF-8", "text", 0);
                }
                else{
                   // alert(compareImgBuffers());
                    if(compareImgBuffers() == -1){         // prev clipped Area doesn't match with the previous, display the new clipped Area (in other words there are some updates (changes) )
                        console.log("Clipped areas don't match, sending new area to lcd ...");
                        displaying = true;
                        setStatusSpan("ACTIVE", "green");
                        showSnackbar("Clipped areas don't match, LCD will be updated ..."); 
                        sendPOSTrequest("http://"+espIP+":80/displayImg", data, "application/json;charset=UTF-8", "text", 0);
                    }
                    else{
                        showSnackbar("Clipped areas match, LCD will be not updated!");
                    }
                }
                prev_clippedImgBuffer = clippedImgBuffer;
            } 
        });
    }

    /****** PARSING 'imgData.data' ARRAY INTO FORMAT 'R;G;B;' ******/
    function createImgBuffer(imgData){
        let imgBuffer = [];
        
        for (let i = 0; i <  imgData.data.length; i += (4*scale)) {         
            let red = imgData.data[i];
            let green = imgData.data[i+1];
            let blue = imgData.data[i+2];
            let rgbColor = `${red};${green};${blue};`;      // one pixels format will be R;G;B;
            imgBuffer.push(rgbColor);
        }
        return imgBuffer;
    }

    /****** COMPARING PREVIOUS SELECTED AREA WITH CURRENT DURING AUTOMATISATION (IF INTERVAL CHECKING IS TURNED ON)******/
    function compareImgBuffers(){
        if(prev_clippedImgBuffer.length == clippedImgBuffer.length){
            for(let i=0; i < clippedImgBuffer.length; i++){
                if(clippedImgBuffer[i] != prev_clippedImgBuffer[i]){
                    return -1;      // they don't match
                } 
            }
        }
        else{
            return -1;      // they don't match
        }
        return 1; // they match
    }

    function sendUrlToServer(){
        HttpResponseToImgSrc(xmlhttpPOST);                
        sendPOSTrequest("/takescreenshot", inputURL, "application/json;charset=UTF-8", "blob", 0);
    }

    function sendPOSTrequest(url, data, content_type, response_type, timeout){
        
        console.log(`Sending POST request to ${url} ...`);

        let obj = `{"data": "${data}"}`;
        xmlhttpPOST.open("POST", url, true);        // false for synchronous request
        xmlhttpPOST.timeout = timeout;              // time in milliseconds
        xmlhttpPOST.responseType = response_type;
        xmlhttpPOST.setRequestHeader("Content-Type", content_type);
        xmlhttpPOST.send(obj);       
    }

    function sendGETrequest(url, content_type, response_type, timeout){
        
        console.log(`Sending GET request to ${url} ...`);

        xmlhttpGET.open("GET", url, false);        // false for synchronous request
      //  xmlhttp.timeout = timeout;              // time in milliseconds
       // xmlhttp.responseType = response_type;
        xmlhttpGET.setRequestHeader("Content-Type", content_type);
        xmlhttpGET.send();       
    }
    
    /******* FUNCTION FOR SHOWING SNACKBAR *******/
    function showSnackbar(message){
        var x = document.getElementById("snackbar");
        x.className = "show";
        x.innerHTML = message;
        setTimeout(function(){ 
            x.className = x.className.replace("show", "");
        }, 6000);
    }

        // set status bars text that can be ACTIVE, INACTIVE and DONE
    function setStatusSpan(message, color){
        $("#span2").text(message);
        $("#span2").css('color', color); 
    }
    
    function delay(milliseconds){
        setTimeout(function() {
          }, milliseconds);
    }

    /****** IMPLEMENTING ACTION LISTENERS *****/
    function initListeners(){

        $("#btn1").click(sendUrlToServer);
        $("#limg1").click(button_Space_action);
        $("#limg2").click(button_Q_action);
        $("#limg3").click(button_S_action);

        $("#dim").change(function(){
        //    scale = parseInt(this.value)/ 128;
        //    scale = (scale == 1) ? 1: 4;
            $("#divToShow").width(parseInt(this.value));
            $("#divToShow").height(parseInt(this.value)); 
        });

        $("#inputBox1").change(function(){
            inputURL = this.value;
        });

        $("#inputBox2").change(function(){
            espIP = this.value;
            espIp = espIP.replace(" ","");
            HttpResponseToVoid(xmlhttpPOST);
            sendPOSTrequest('/espIP',espIP, "application/json;charset=UTF-8", "text/plain",0);
        });

        $("#timer").change(function(){
            interval = parseInt(this.val)  * 60 * 1000;
        });

        $("#chkbox1").change(function(){
        
            if(this.checked == true){
                if(imgSrc != ""){       // check if was captured screenshot
                     
                    if(clippedImgBuffer != ""){        // if already was selected area
                        $("#span1").text("ON");
                        showSnackbar("Automated check started!");

                        HttpResponseForAutomation(xmlhttpPOST);
                        sendPOSTrequest("/takescreenshot", inputURL, "application/json;charset=UTF-8", "blob",0);
                        //if(objIt1){
                      //      setIntervalObject1(false);      //stop
                           // clearInterval(ojIt1);       
                       // }
                        // todo it2 for checking sending next parts

                        setIntervalObject1(true);       //start

                        //setIntervalObject2(false);      //stop
                        //setIntervalObject2(true);       //start
                        /*
                        objIt1 = setInterval(() => {
                            HttpResponseToAutomation();
                            sendPOSTrequest("/takescreenshot", inputURL, "application/json;charset=UTF-8", "blob",0);
                        }, interval);        
                        */           
                    }
                }
                else{
                    showSnackbar("No available screenshot!");
                }

            }
            else{
                //clearInterval(objIt1);
                setIntervalObject1(false);      //stop
                $("#span1").text("OFF");
                setStatusSpan("INACTIVE", "red"); 
                displaying = false;
                showSnackbar("Automated check terminated!");
            }
        });

        $(document).on('mousemove', function(e){      //document
              mouseX = e.pageX + 10;
              mouseY = e.pageY + 10;
            
            $('#divToShow').css({
                left:  mouseX,
                top:   mouseY
            });
            
          // mouseX = (e.pageX - $(this).offset().left);
         //  mouseY = e.pageY;//(e.pageY - $(this).offset().top);     // for displaying clipBox
         //  $('#divToShow').offset({ top: mouseY, left: mouseX });
         //  mouseY = (e.pageY - $(this).offset().top);               // for clipArea
        });

        document.addEventListener('keypress',function (e) {
            if(e.charCode == 113){  //Q
                button_Q_action();
            }
            if(e.charCode == 115){   // S
                button_S_action();
            }
            if(e.charCode == 32){   // space
                button_Space_action();
            }
        });
    } 
    
    function button_Q_action(){     // terminate displaying
        if(displaying == true){
            displaying = false;  
            setStatusSpan("INACTIVE", "red");
            $("#span1").text("OFF");    // this responds to automation
            showSnackbar("Displaying terminated!");
            setIntervalObject2(false);      // stop
           // clearInterval(objIt2);  
            
        }
        else{
            showSnackbar("No active displaying!");
        }
    }

    function button_S_action() {        // hide/ unhide square (cliparea)
        squareHidden =! squareHidden;

        if(squareHidden){   // true
            $("#divToShow").hide();
        }
        else{
            $("#divToShow").show();
        }
    }

    function button_Space_action(){     // send selected area to lcd if the square is visible
        if(!squareHidden){  
            if(imgSrc != ""){
                clipX = mouseX;
                clipY = mouseY;
                takePartOfImg(false);
                showSnackbar("Sending clipped area to LCD ...");

                //clearInterval(objIt2);
               // setIntervalObject2(false);      // stop
                HttpResponseForCheckNext(xmlhttpGET);
                setIntervalObject2(true);       // starts it
                // coment these lines if using socket checking
                
                /*
                objIt2 = setInterval(() => {
                    sendGETrequest("/avaiableNext","application/json;charset=UTF-8", "application/json",0);
                }, 2* 1000);             
                */
                
            }           
        }
        else{
            showSnackbar("Square is hidden, unable to set clip area!");
        }
    }

    // at the beginning, setting up starting values
    function loadDefaultValues(){

        $('#chkbox1').attr('checked', false); // Unchecks checkbox which represents automatizated displaying of selected area
        $("#dim").val('128');         // setting default dimensions value to 128
        setStatusSpan("INACTIVE", "red");
        inputURL = $("#inputBox1").val();
       // scale = parseInt($("#dim").val())/128;
       // scale = (scale == 1) ? 1: 4;
        interval = parseInt($("#timer").val()) * 60 * 1000;;
        espIP = $("#inputBox2").val();

        HttpResponseToVoid(xmlhttpPOST);
        sendPOSTrequest('/espIP',espIP, "application/json;charset=UTF-8", "text/plain",0);

    }

    initListeners();
    loadDefaultValues();
}); 